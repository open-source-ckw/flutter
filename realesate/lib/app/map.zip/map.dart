import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:carousel_slider/carousel_slider.dart';
import 'package:fluster/fluster.dart';
import 'package:flutter/cupertino.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';
import 'layout/listing/filter.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../app/core/global.dart' as globals;
import 'layout/listing/listing_box.dart';
import 'loader.dart';
import 'package:intl/intl.dart' as intl;

class GMap extends StatefulWidget {
  Map<String, dynamic>? filter;
  bool isLoading;
  ValueSetter<Map<String, dynamic>> refreshData;
  List listAllData = [];
  GMap({
    Key? key,
    this.filter,
    required this.listAllData,
    required this.isLoading,
    required this.refreshData,
  }) : super(key: key);

  @override
  State<GMap> createState() => GMapState(this.filter);
}

class GMapState extends State<GMap> {
  CarouselController buttonCarouselController = CarouselController();
  GoogleMapController? mapController;
  Map<String, dynamic>? filter;
  bool zoomGesturesEnabled = true;
  bool scrollGesturesEnabled = true;
  bool showdata = false;
  PageController? _pageController;
  GMapState(this.filter);

  int? _activeMarker;
  List<Marker> listMarker = [];
  Map<String, Marker> _mapMarkers = <String, Marker>{};
  Completer<GoogleMapController> _controller = Completer();
  int? prevPage;
  LatLng? currentPostion;
  double mapzoom = 20.00;
  List<LatLng> _markerList = [];
  bool goToCenter = false;
  bool slidr = true;
  CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(double.parse(globals.mapConfige['default_lat']),
        double.parse(globals.mapConfige['default_lang'])),
    zoom: 8.00,
  );
  static LatLng _center =
  (globals.mapConfige.containsKey('default_lat') == true)
      ? LatLng(double.parse(globals.mapConfige['default_lat']),
      double.parse(globals.mapConfige['default_lang']))
      : LatLng(49.246292, -123.116226);

  LatLng? _lastMapPosition = _center;

  List isCluster = [];
  Map cluster_group = {};
  Map cluster_group_OEMarkersRef = {};
  Map<String, List> cluster_group_styles = {};
  var objMapZoomEvent = '';
  bool _areMarkersLoading = true;


  moveCamera(double lat, double lng) async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(lat, lng),
        zoom: this.mapzoom,
        bearing: 45.0,
        tilt: 45.0)));
  }

  var myIcon, greencir;

  @override
  void initState() {
    _pageController?.dispose();
    BitmapDescriptor.fromAssetImage(
        ImageConfiguration(size: Size(48, 48)), 'assets/marker_orange.png')
        .then((onValue) {
      setState(() {
        myIcon = onValue;
        // createMarkers();
        //MapMarker(position: LatLng(49.246292, -123.116226), id: '66');
      });
    });
    BitmapDescriptor.fromAssetImage(
        ImageConfiguration(size: Size(1, 1)), 'assets/active.png')
        .then((onValue) {
      setState(() {
        greencir = onValue;
      });
    });
    // Set default sort option
    if (this.filter == null || this.filter?.containsKey('so') == false) {
      this.filter = {};
      this.filter?.addAll({'so': 'price', 'sd': 'desc'});
    }
    super.initState();
  }

  @override
  void dispose() {
    mapController?.dispose();
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if(this._mapMarkers.length <= 0 && widget.listAllData != null &&
        widget.listAllData.length > 0){
      createMarkers();
    }

    return Scaffold(
        body: Stack(
          children: [
            GoogleMap(
              onMapCreated: _onMapCreated,
              initialCameraPosition: _kGooglePlex,
              zoomGesturesEnabled: zoomGesturesEnabled,
              scrollGesturesEnabled: scrollGesturesEnabled,
              markers: Set<Marker>.of(this._mapMarkers.values),
              //markers: _markers,
              onCameraMoveStarted: () {
                if (_activeMarker == null && goToCenter == false) {
                  onCameraMS();
                }

                goToCenter = false;
              },
              onCameraMove: _onCameraMove,
              onTap: (data) async {
                var icon_image = 'assets/marker_orange.png';
                if (_activeMarker != null &&
                    widget.listAllData[_activeMarker ?? 0]['PropertyType'] ==
                        'Rental' ||
                    widget.listAllData[_activeMarker ?? 0]['PropertyType'] ==
                        'ResidentialLease') {
                  icon_image = 'assets/marker_yellow.png';
                } else {
                  BitmapDescriptor.fromAssetImage(
                      ImageConfiguration(size: Size(48, 48)), icon_image);
                }
                _activeMarker = null;
                BitmapDescriptor.fromAssetImage(
                    ImageConfiguration(size: Size(48, 48)), icon_image)
                    .then((onValue) {
                  setState(() {
                    myIcon = onValue;
                    this._mapMarkers.clear();
                    createMarkers();
                  });
                });
              },
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 100),
              child: Align(
                alignment: Alignment.bottomRight,
                child: FloatingActionButton(
                  backgroundColor: Colors.white,
                  onPressed: () {
                    final result = pushNewScreen(context,
                        withNavBar: false,
                        screen: Filter(filter: this.filter, onPage: 'Map'));
                    result.then((value) {
                      setState(() {
                        // If apply filters with new data OR didnt perform clear filter on filter page that time need to clear markers to create new markers from build.
                        if (value is Map) this._mapMarkers.clear();
                        this.filter = value;
                        refreshDataFP('refresh');
                      });
                    });
                  },
                  child: Icon(
                    Icons.filter_alt_outlined,
                    size: 32.0,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            //(widget.isLoading == true || _areMarkersLoading) ? loader() : emptyBox(),
          ],
        ));
  }

  Widget loader() {
    return Container(
      decoration: new BoxDecoration(
        borderRadius: new BorderRadius.circular(10.0),
        color: Colors.white60,
      ),
      alignment: AlignmentDirectional.center,
      child: new Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Loader(),
          Text(
            "Loading...",
          ),
        ],
      ),
    );
  }

  _onMarkerTapped(markerId) {
    loader();
    Widget slider = buildCarousel(markerId);
    showModalBottomSheet(
        context: context,
        isScrollControlled: false,
        backgroundColor: Colors.transparent,
        builder: (BuildContext bc) {
          return slider;
        });
  }

  buildCarousel(markerId) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: CarouselSlider(
        options: CarouselOptions(
          initialPage: markerId,
          autoPlay: false,
          enlargeCenterPage: true,
          onPageChanged: (int index, CarouselPageChangedReason reason) async {
            _onScroll(index);
          },
        ),
        items: Slider(widget.listAllData),
      ),
    );
  }

  Slider(data) {
    loader();
    slidr = false;
    List<Widget> fls = <Widget>[];
    data.forEach((flsilder) {
      fls.add(ListingBox(data: flsilder));
    });
    return fls;
  }

  LatLngBounds getBounds(
      List<LatLng> markers,
      ) {
    var lngs =
    markers.map<double>((m) => m.longitude).toList(); // Converted to list
    var lats =
    markers.map<double>((m) => m.latitude).toList(); // Converted to list

    double topMost = lngs.reduce(max);
    double leftMost = lats.reduce(min);
    double rightMost = lats.reduce(max);
    double bottomMost = lngs.reduce(min);

    LatLngBounds bounds = LatLngBounds(
      northeast: LatLng(rightMost, topMost),
      southwest: LatLng(leftMost, bottomMost),
    );

    return bounds;
  }

  onCameraMS() async {
    final GoogleMapController g_controller = await _controller.future;
    var bound = await g_controller.getVisibleRegion();
    late LatLngBounds c_latLong;

    if (bound != null) {
      //var boundaries = '${bound.southwest.latitude}, ${bound.southwest.longitude}, ${bound.northeast.latitude}, ${bound.northeast.longitude}';
      if (mounted) {
        setState(() {
          this.filter?['map'] =
          '${bound.southwest.latitude},${bound.southwest.longitude},${bound.northeast.latitude},${bound.northeast.longitude}';
          //this._mapMarkers.});
        });
      }
      goToCenter = false;
    }
  }

  createMarkers() async {
    print('marker data');
    var icon_type = myIcon;
    if (widget.listAllData.length > 0 && myIcon != null) {
      print('markerdata');
      for (int i = 0; i < widget.listAllData.length; i++) {
        print('markerdata1');
        if (widget.listAllData[i]['Latitude'] != null &&
            widget.listAllData[i]['Longitude'] != null) {
          /*print('markerdata2');
          print(widget.listAllData[i]['PropertyType']);
          final MarkerId markerId =
          MarkerId(widget.listAllData[i]['ListingID_MLS']);
          if (widget.listAllData[i]['PropertyType'] == 'Rental' ||
              widget.listAllData[i]['PropertyType'] == 'ResidentialLease') {
            print('markerdata3');
            icon_type = await BitmapDescriptor.fromAssetImage(
                ImageConfiguration(size: Size(48, 48)),
                'assets/marker_yellow.png');
          } else {
            icon_type = myIcon;
          }*/
          print('*************************');
          print(widget.listAllData[i]['ListingID_MLS']);
          String sortPrice =
          PriceFormat(double.parse(widget.listAllData[i]['ListPrice']));

          Uint8List? markerIcon = await getBytesFromCanvas(
              150, 80, '\$${sortPrice}', widget.listAllData[i]['ListingID_MLS']);

          final Marker marker =
          getSingleMarker(widget.listAllData[i], markerIcon, i);
          this._mapMarkers[widget.listAllData[i]['ListingID_MLS']] = marker;
          //final Marker marker = await getSingleMarker(widget.listAllData[i], icon_type, i);
          //this._mapMarkers[markerId] = marker;
          _markerList.add(LatLng(
              double.parse(widget.listAllData[i]['Latitude']),
              double.parse(widget.listAllData[i]['Longitude'])));
        }
      }
    }
    if (_markerList.length > 0 && this.filter?.containsKey('map') == false) {
      goToCenter = true;
      camcenter(_markerList);
    }
    setState(() {
      _markerList;
    });
  }

  refreshDataFP(String s) {
    var data = {
      'action': 'refresh',
      'filter': this.filter,
    };
    widget.refreshData(data);
  }

  getSingleMarker(dynamic objProp, markerIcon, index)  {
    final formatter = new intl.NumberFormat("#,##0");
    var listprice = formatter.format(double.parse(objProp['ListPrice'].toString()));

    var icon_type = myIcon;
    if (objProp['PropertyType'] == 'Rental' ||
        objProp['PropertyType'] == 'ResidentialLease') {
      icon_type =  BitmapDescriptor.fromAssetImage(
          ImageConfiguration(size: Size(48, 48)),
          'assets/marker_yellow.png');
    } else {
      icon_type = myIcon;
    }
    print('data');
    print(objProp);
    return Marker(
      markerId: MarkerId(objProp['ListingID_MLS']),
      icon: BitmapDescriptor.fromBytes(markerIcon),
      position: LatLng(
        double.parse(widget.listAllData[index]['Latitude']),
        double.parse(widget.listAllData[index]['Longitude']),
      ),
      infoWindow: InfoWindow(
        title: listprice,
      ),
      onTap: () async {
        _onMarkerTapped(index);
        if (_activeMarker != null) {
          int? oldActivemarker = _activeMarker;
          _activeMarker = null;

          // Set old marker as old color
          activePropertyMarker(oldActivemarker);
        }
        _activeMarker = index;

        var new_icon = await BitmapDescriptor.fromAssetImage(
            const ImageConfiguration(size: Size(48, 48)),
            'assets/activemarker.png');
        // Set new active marker
        activePropertyMarker(index);

      },
    );
  }
  camcenter(List<LatLng> markers) {
    LatLngBounds c_latLong = getBounds(markers);

    CameraUpdate u2 = CameraUpdate.newLatLngBounds(c_latLong, 20);
    mapController?.animateCamera(u2).then((void v) {
      check(u2, this.mapController!);
    });
  }

  void check(CameraUpdate u, GoogleMapController c) async {
    c.animateCamera(u);
    mapController?.animateCamera(u);
    LatLngBounds l1 = await c.getVisibleRegion();
    LatLngBounds l2 = await c.getVisibleRegion();
    if (l1.southwest.latitude == -90 || l2.southwest.latitude == -90)
      check(u, c);
  }

  activePropertyMarker(index) async {
    print('Active index ========== ');
    print(index);
    /*final marker =
    getSingleMarker(widget.listAllData[index], markerIcon, index);
    if (this.mounted) {
      setState(() {
        this._mapMarkers[MarkerId(widget.listAllData[index]['ListingID_MLS'])] =
            marker;
      });
    }*/
    String sortPrice =
    PriceFormat(double.parse(widget.listAllData[index]['ListPrice']));

    Uint8List? markerIcon = await getBytesFromCanvas(
        150, 80, '\$${sortPrice}',widget.listAllData[index]['ListingID_MLS']);

    final marker =
    getSingleMarker(widget.listAllData[index], markerIcon, index);
    if (this.mounted) {
      setState(() {
        this._mapMarkers[widget.listAllData[index]['ListingID_MLS']] = marker;
      });
    }
  }
  /*activePropertyMarkerlable(index,markerIcon) async {
    // activeMarker = index;
    String sortPrice =
    PriceFormat(double.parse(widget.listAllData[index]['ListPrice']));

    Uint8List? markerIcon = await getBytesFromCanvas(
        150, 80, '\$${sortPrice}',widget.listAllData[index]['ListingID_MLS']);

    final marker =
    getSingleMarker(widget.listAllData[index], markerIcon, index);
    if (this.mounted) {
      setState(() {
        this._mapMarkers[widget.listAllData[index]['ListingID_MLS']] = marker;
      });
    }
  }*/
  Future<Uint8List?> getBytesFromCanvas(
      int width, int height, String price, dynamic mlsMarks) async {
    final ui.PictureRecorder pictureRecorder = ui.PictureRecorder();
    final Canvas canvas = Canvas(pictureRecorder);
    final Paint paint = Paint()
      ..color = (_activeMarker != null &&
          widget.listAllData[_activeMarker??0]['ListingID_MLS'] == mlsMarks)
          ? Theme.of(context).errorColor
          : Theme.of(context).primaryColor;



    //final Radius radius = Radius.circular(20.0);
    final double radius = width / 2;
    final double d_width = double.parse(width.toString());
    final double d_height = double.parse(height.toString());
    canvas.drawCircle(Offset(radius, radius), radius, paint);
    //canvas.drawRect(Offset(radius, radius) & Size(radius, radius), Paint());
    //canvas.drawRect(Offset(radius, radius) &  Size(d_width, d_height), Paint());

    TextPainter painter = TextPainter(textDirection: TextDirection.ltr);
    painter.text = TextSpan(
      text: price,
      style: TextStyle(color: Colors.white, fontSize: 26.0),
    );
    painter.layout();
    painter.paint(canvas,
        Offset(radius - painter.width / 2.7, radius - painter.height / 2));
    final img = await pictureRecorder
        .endRecording()
        .toImage(radius.toInt() * 2, radius.toInt() * 2);
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    return data?.buffer.asUint8List();
  }
  Future<Uint8List?> __getBytesFromCanvas(
      int width, int height, String price, dynamic mlsMarks) async {
    final ui.PictureRecorder pictureRecorder = ui.PictureRecorder();
    final Canvas canvas = Canvas(pictureRecorder);
    final Paint paint = Paint()
      ..color = (_activeMarker != null &&
          widget.listAllData[_activeMarker??0]['ListingID_MLS'] == mlsMarks)
          ? Theme.of(context).errorColor
          : Theme.of(context).toggleableActiveColor;
    //final Radius radius = Radius.circular(20.0);
    final double radius = width / 2.5;
    canvas.drawCircle(Offset(radius, radius), radius, paint);

    TextPainter painter = TextPainter(textDirection: TextDirection.ltr);
    painter.text = TextSpan(
      text: price,
      style: TextStyle(color: Colors.white, fontSize: 26.0),
    );
    painter.layout();
    painter.paint(canvas,
        Offset(radius - painter.width / 2, radius - painter.height / 2));
    final img = await pictureRecorder
        .endRecording()
        .toImage(radius.toInt() * 2, radius.toInt() * 2);
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    return data?.buffer.asUint8List();
  }

  void _onCameraMove(CameraPosition position) {
    //// Added with TEMP
    _lastMapPosition = position.target;
    if (this.mounted) {
      setState(() {
        _lastMapPosition = position.target;
        mapzoom = position.zoom;
        _center = position.target;
      });
    }
  }

  Widget emptyBox() {
    return new SizedBox(
      width: 0.0,
      height: 0.0,
    );
  }
  void Controller() {
    var deviceOrientetion = MediaQuery.of(context).orientation;
    _pageController = PageController(
        initialPage: (_activeMarker != null) ? _activeMarker ?? 0 : 0,
        viewportFraction:
        (deviceOrientetion == Orientation.portrait) ? 0.8 : 0.5)
      ..addListener(_onScroll(_activeMarker!));
  }
  _onScroll(int index) async {
    if (widget.listAllData != null &&  index != prevPage &&
        (widget.listAllData.length != 0 && widget.isLoading == false)) {
      moveCamera(double.parse(widget.listAllData[index]['Latitude']),
          double.parse(widget.listAllData[index]['Longitude']));


      prevPage = index;
      /*if (_activeMarker != null) {
        int? oldActivemarker = _activeMarker;
        _activeMarker = null;
        var icon_type_n = myIcon;
        if (widget.listAllData[index]['PropertyType'] == 'Rental' ||
            widget.listAllData[index]['PropertyType'] == 'ResidentialLease') {
          icon_type_n = await BitmapDescriptor.fromAssetImage(
              ImageConfiguration(size: Size(48, 48)),
              'assets/marker_yellow.png');
        }
        activePropertyMarker(oldActivemarker,icon_type_n);
      }
      _activeMarker = prevPage;
      var new_icon = await BitmapDescriptor.fromAssetImage(
          ImageConfiguration(size: Size(48, 48)), 'assets/activemarker.png');
      activePropertyMarker(prevPage,new_icon);*/
      if (_activeMarker != null) {
        // Store oldactive marker index to new variable
        int? oldActivemarker = _activeMarker;
        // Set active markers index to null becuase we need primary color for old marker
        _activeMarker = null;
        // Set old marker color as default
        activePropertyMarker(oldActivemarker);
      }
      // activeMarker = propertyList[i].MLS_NUM ;
      // Change index of new active marker
      _activeMarker = prevPage;
      // Change color of new active marker
      activePropertyMarker(prevPage);
    }
  }

  void _onMapCreated(GoogleMapController controller) {
    if (this.mounted) {
      setState(() {
        mapController = controller;
      });
    }
    var style = [
      {
        "elementType": "geometry",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "elementType": "labels.icon",
        "stylers": [
          {"visibility": "off"}
        ]
      },
      {
        "elementType": "labels.text.fill",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "elementType": "labels.text.stroke",
        "stylers": [
          {"color": "#2A2A2B"}
        ]
      },
      {
        "featureType": "administrative.land_parcel",
        "elementType": "labels.text.fill",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "poi",
        "elementType": "geometry",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "poi",
        "elementType": "labels.text.fill",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "poi.park",
        "elementType": "geometry",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "poi.park",
        "elementType": "labels.text.fill",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "road",
        "elementType": "geometry",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "road.arterial",
        "elementType": "labels.text.fill",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "road.highway",
        "elementType": "geometry",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "road.highway",
        "elementType": "labels.text.fill",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "road.local",
        "elementType": "labels.text.fill",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "transit.line",
        "elementType": "geometry",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "transit.station",
        "elementType": "geometry",
        "stylers": [
          {"color": "#ECEBE9"}
        ]
      },
      {
        "featureType": "water",
        "elementType": "geometry",
        "stylers": [
          {"color": "#B1BDD6"}
        ]
      },
      {
        "featureType": "water",
        "elementType": "labels.text.fill",
        "stylers": [
          {"color": "#B1BDD6"}
        ]
      }
    ];
    mapController?.setMapStyle(jsonEncode(style));
    _controller.complete(controller);
  }
  PriceFormat(double nStr, [noOfDecimal]) {
    if (nStr != null) {
      dynamic tmpNo;
      var tmpStr;
      if (nStr > 1000000000000) {
        tmpNo = (nStr / 1000000000000);
        noOfDecimal = (noOfDecimal != null) ? noOfDecimal : 2;
        tmpStr = 'T';
      } else if (nStr >= 1000000000) {
        tmpNo = (nStr / 1000000000);
        noOfDecimal = (noOfDecimal != null) ? noOfDecimal : 2;
        tmpStr = 'B';
      } else if (nStr >= 1000000) {
        tmpNo = (nStr / 1000000);
        noOfDecimal = (noOfDecimal != null) ? noOfDecimal : 2;
        tmpStr = 'M';
      } else if (nStr >= 1000) {
        tmpNo = (nStr / 1000).round();
        tmpStr = 'K';
      }
      if (tmpNo != '') {
        if (tmpNo % (1) != 0) {
          if (noOfDecimal != null) {
            return tmpNo.toStringAsFixed(noOfDecimal).toString() + tmpStr;
          } else {
            return tmpNo.round().toString() + tmpStr;
          }
        } else {
          return tmpNo.toString() + tmpStr;
        }
      } else {
        return nStr.toString();
      }
    }
  }
}
